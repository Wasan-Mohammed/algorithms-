import java.util.Scanner;

public class Main
{
  
public static void main (String[]args)
  {
	
Scanner input = new Scanner (System.in);
	
System.out.println ("Enter first number: ");
	
int n1 = input.nextInt ();
	
System.out.println ("Enter second number: ");
	
int n2 = input.nextInt ();
// GCD = greatest common divisor	
System.out.println ("GCD of two numbers " + n1 + " and " + n2 + " is: " +
						 findGCD (n1, n2));
  
} 
private static int findGCD (int n1, int n2)
  {
	
if (n2 == 0)
	  {
		
return n1;
	  
}
	
return findGCD (n2, n1 % n2);
  
}

}


